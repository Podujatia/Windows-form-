﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
                podujatia.Clear();
                foreach (string str in listBox1.Items)
                {
                    podujatia.Add(str);
                    textBox1.CharacterCasing = CharacterCasing.Normal;
                }
        }
        List<string> podujatia = new List<string>();
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) == false)
            {
                listBox1.Items.Clear();
                foreach (string str in podujatia)
                {
                    if (str.StartsWith(textBox1.Text))
                    {
                        listBox1.Items.Add(str);
                    }
                }
            }
            else if (textBox1.Text == "")
            {
                listBox1.Items.Clear();
                foreach (string str in podujatia)
                {
                    listBox1.Items.Add(str);

                }
            }
        }
    }
}
